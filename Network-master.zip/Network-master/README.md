To get started, first click the Download ZIP button to the right to download this tutorial's assets.

NetworkAPI
==========

Application to showcase features of Network APIs.


# Purpose
This Application will showcase the following features of Network APIs

* Passing request to service provider using required parameters
* Parsing the JSON object received for desired Information

# Supported platforms:
**Mobile**
 * Android
 * iPhone
 * BlackBerry 

**Tablet** 
 * Android
 * iPad
