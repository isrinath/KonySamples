//Template File
function initializefrmFooter() {
    var image2121043302122534 = new kony.ui.Image2({
        "id": "image2121043302122534",
        "isVisible": true,
        "src": "cpyrite.png",
        "imageWhenFailed": null,
        "imageWhileDownloading": null
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "referenceWidth": null,
        "referenceHeight": null,
        "containerWeight": 100
    }, {});
    hbox1928402615924 = new kony.ui.Box({
        "id": "hbox1928402615924",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 11,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "vExpand": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hbox1928402615924.add(
    image2121043302122534);
};