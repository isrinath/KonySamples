//
//  SigCapCustomWidget.h
//  VMAppWithKonylib
//
//  Created by Srinivas Vemula on 7/15/15.
//
//

#import "CWIWidget.h"
#import "KonyCWIEnvironment.h"
#import "T1Autograph.h"
#import "lglobals.h"

@interface SigCapCustomWidget: UIControl <CWIWidget,T1AutographDelegate>


@property (nonatomic, strong) KonyCWIEnvironment* konyEnv;
@property (strong) T1Autograph *autograph;
@property (strong, nonatomic) NSString *sigbase64;
@property (strong, nonatomic) NSString *clearsig;

@end