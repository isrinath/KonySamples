//
//  SigCapCustomWidget.m
//  VMAppWithKonylib
//
//  Created by Srinivas Vemula on 7/15/15.
//
//

#import <Foundation/Foundation.h>
#import "SigCapCustomWidget.h"
#import "KonyUIContext.h"

@implementation SigCapCustomWidget{
    CGFloat originX, originY, playerFrameWidth, playerFrameHeight;
    UIDeviceOrientation currentOrientation;
    CGFloat sigHeightInPercent, SigWidthInPercent;
}

#pragma mark Initialize the Custom Widget

/***
 Below are the Kony Custom Widget protocol methods
 ***/
- (id)initWithFrame:(CGRect) frame{
    self = [super initWithFrame:frame];
    return self;
}

- (id)initWithEventDelegate:(id) eventDelegate withKonyEnvironment:(id) env{
    
    self = [self init];
    self.konyEnv = (KonyCWIEnvironment*) env;
    
    [self setDefaultValues];
    
    return self;
}

# pragma mark Custom Widget Model update related methods

/***
 Method to read property values if they are changed by the user
 ***/
- (void) modelUpdatedForProperty:(NSString*) propertyName  withOldValue:(id) oValue newValue:(id) nValue{
    
    if ([propertyName isEqualToString:@"clearsig"]){
        [self.autograph reset:self];
        
     }else if ([propertyName isEqualToString:@"sigbase64"]){
         self.sigbase64 = nValue;
         oValue = nValue;
        
     }
   
}

# pragma mark View releated methods

- (UIView*) getWidgetView{
    return self;
}

- (CGSize) getPreferredSizeForGivenSize: (CGSize) givenSize{
    CGSize preferredSize = givenSize;
    originX = 0;
    originY = 0;
    sigHeightInPercent = 40.0;
    SigWidthInPercent = 100;
    preferredSize.width = ([UIScreen mainScreen].bounds.size.width) * (SigWidthInPercent/100.0);
    preferredSize.height = ([UIScreen mainScreen].bounds.size.height) * (sigHeightInPercent/100.0);
    
    return preferredSize;
    
}

- (void) setWidgetViewFrame: (CGRect) frame{
    
    self.frame = frame;
    self.clipsToBounds = false;
    [self setDefaultValues];
}

/***
 Method to set the default signature screen.
 ***/
-(void)setDefaultValues{
  
    
    playerFrameHeight = self.frame.size.height;
    playerFrameWidth =  self.frame.size.width; //[UIScreen mainScreen].bounds.size.width - (originX*2);
    
    
    CGFloat padding = self.frame.size.width / 15;
    UIView *autographView = [[UIView alloc] initWithFrame:CGRectMake(padding, originY, playerFrameWidth, playerFrameHeight)];
    
    autographView.layer.borderColor  = [UIColor blackColor].CGColor;
    autographView.layer.borderWidth  = 3;
    autographView.layer.cornerRadius = 10;
    autographView.exclusiveTouch=true;
    [autographView setBackgroundColor:[UIColor whiteColor]];
    [self addSubview:autographView];
    [autographView setExclusiveTouch:YES];

    
    // Initialize Autograph library
    self.autograph = [T1Autograph autographWithView:autographView delegate:self];
    
    // to remove the watermark, get a license code from Ten One, and enter it here
   // [self.autograph setLicenseCode:@"a9668f950eb2a30109ab1666bcc9cf885337095f"];
    
    // Clips signature UIImage to the bounds of the signature capture UIView.  Default is NO
    [self.autograph setClipSignatureToBounds:YES];
    
    // show current date.  Default is NO
    //[self.autograph setShowDate:YES];
    
    [self setTag: 1320];
   
    
}


#pragma mark - T1Autograph Delegate Methods

- (void)autographDidCancelModalView:(T1Autograph *)autograph {
    NSLog(@"Autograph modal signature has been cancelled");
}

- (void)autographDidCompleteWithNoSignature:(T1Autograph *)autograph {
    NSLog(@"User pressed the done button without signing");
}

- (void)autograph:(T1Autograph *)autograph didEndLineWithSignaturePointCount:(NSUInteger)count {
    NSLog(@"Line ended with total signature point count of %d", (int)count);
    
    if((int) count>0){
        [self.autograph done:self];
       // [self.autograph reset:self];
    }
    // Note: You can use the 'count' parameter to determine if the line is substantial enough to enable the done or clear button.
}

- (void)autograph:(T1Autograph *)autograph willCompleteWithSignature:(T1Signature *)signature {
    NSLog(@"Autograph will complete with signature");
}

- (void)autograph:(T1Autograph *)autograph didCompleteWithSignature:(T1Signature *)signature {
    // Log information about the signature
    NSLog(@"-- Autograph signature completed. --");
    NSMutableArray *valueOfDic;
    
    UIImage *sigImage = [UIImage imageWithData:signature.imageData];
    NSString *lImgStr = [UIImagePNGRepresentation(sigImage) base64Encoding];
    
    NSMutableDictionary * infoTable = [NSMutableDictionary dictionary];
    [infoTable setObject:@"true" forKey:@"isDoneClicked"];
    [infoTable setObject:lImgStr forKey:@"sigImage"];
    valueOfDic = [[NSMutableArray alloc] initWithObjects:infoTable, nil];
    // set the base64 back to widget property sigbase64
    [self.konyEnv.model setValue:lImgStr forKey:@"sigbase64"];
    
}

/***
 dealloc method to free up the objects
 ***/
-(void) dealloc{
    
    [super dealloc];
}
@end
