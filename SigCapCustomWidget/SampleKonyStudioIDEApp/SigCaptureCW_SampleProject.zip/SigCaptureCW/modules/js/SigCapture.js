function captureSignature(){
	kony.print("&&&&&&& custom object "+frmSigCapCW.custSigWid.sigbase64)
	frmSigCapCW.enableScrolling=true;
	frmSigCapCW.custSigWidFlex.isVisible=false;
	frmSigCapCW.sigimage.isVisible=true;
	frmSigCapCW.sigimage.base64=frmSigCapCW.custSigWid.sigbase64;
}

function callbackfromSigCapture(imgData){
	kony.print("******* imgdata is "+imgData);
}
function clearSignature(){
	frmSigCapCW.custSigWid.clearsig="";
	//kony.print("******* imgdata is "+imgData);
}

function showFlex(){
	//kony.print("&&&&&&& custom object "+frmSigCapCW.custSigWid.sigbase64)
	frmSigCapCW.enableScrolling=false;
	frmSigCapCW.custSigWidFlex.isVisible=true;
	frmSigCapCW.sigimage.isVisible=false;
}