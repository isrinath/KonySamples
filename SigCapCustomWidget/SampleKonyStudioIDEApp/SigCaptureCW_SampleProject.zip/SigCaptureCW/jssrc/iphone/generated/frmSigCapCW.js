//Form JS File
function frmSigCapCW_button122720985063_onClick_seq0(eventobject) {
    captureSignature.call(this);
};

function frmSigCapCW_button122720985071_onClick_seq0(eventobject) {
    clearSignature.call(this);
};

function frmSigCapCW_button1227209850515_onClick_seq0(eventobject) {
    showFlex.call(this);
};

function addWidgetsfrmSigCapCW() {
    var sigimage = new kony.ui.Image2({
        "id": "sigimage",
        "top": "50dp",
        "left": "37dp",
        "width": "245dp",
        "height": "150dp",
        "zIndex": 1,
        "isVisible": false,
        "src": null,
        "imageWhenFailed": null,
        "imageWhileDownloading": null
    }, {
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glossyEffect": constants.IMAGE_GLOSSY_EFFECT_DEFAULT
    });
    var SigCapCustomWidgetcustom198404341593 = new SigCapCustomWidget.SigCapCustomWidget({
        "id": "SigCapCustomWidgetcustom198404341593",
        "top": "438dp",
        "left": "5dp",
        "width": "246dp",
        "height": "117dp",
        "zIndex": 1,
        "image": null,
        "isVisible": true,
        "hExpand": true,
        "vExpand": false,
        "sigbase64": null,
        "clearsig": null
    }, {
        "widgetAlign": 5,
        "containerWeight": 0,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "widgetName": "SigCapCustomWidget"
    });
    var label122720985047 = new kony.ui.Label({
        "id": "label122720985047",
        "top": "0dp",
        "left": "5dp",
        "width": "207dp",
        "height": "66dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Capture Signature",
        "skin": "lblNormal"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var button122720985063 = new kony.ui.Button({
        "id": "button122720985063",
        "top": "180dp",
        "left": "5dp",
        "width": "132dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Capture",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmSigCapCW_button122720985063_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button122720985071 = new kony.ui.Button({
        "id": "button122720985071",
        "top": "180dp",
        "left": "145dp",
        "width": "135dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Clear",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmSigCapCW_button122720985071_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var custSigWid = new SigCapCustomWidget.SigCapCustomWidget({
        "id": "custSigWid",
        "top": "50dp",
        "left": "5dp",
        "width": "270dp",
        "height": "117dp",
        "zIndex": 1,
        "image": null,
        "isVisible": true,
        "hExpand": true,
        "vExpand": false,
        "sigbase64": null,
        "clearsig": null
    }, {
        "widgetAlign": 5,
        "containerWeight": 0,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "widgetName": "SigCapCustomWidget"
    });
    var custSigWidFlex = new kony.ui.FlexContainer({
        "id": "custSigWidFlex",
        "top": "50dp",
        "left": "0dp",
        "width": "200%",
        "height": "300dp",
        "zIndex": 1,
        "isVisible": false,
        "clipBounds": true,
        "Location": "[0,50]",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    custSigWidFlex.setDefaultUnit(kony.flex.DP)
    custSigWidFlex.add(
    label122720985047, button122720985063, button122720985071, custSigWid);
    var button1227209850515 = new kony.ui.Button({
        "id": "button1227209850515",
        "top": "0dp",
        "left": "5dp",
        "width": "132dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Capture",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmSigCapCW_button1227209850515_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var flexContainer198404341524 = new kony.ui.FlexContainer({
        "id": "flexContainer198404341524",
        "top": "0dp",
        "left": "0dp",
        "width": "100%",
        "height": "300%",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,0]",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    flexContainer198404341524.setDefaultUnit(kony.flex.DP)
    flexContainer198404341524.add(
    sigimage, SigCapCustomWidgetcustom198404341593, custSigWidFlex, button1227209850515);
    frmSigCapCW.add(
    flexContainer198404341524);
};

function frmSigCapCWGlobals() {
    var MenuId = [];
    frmSigCapCW = new kony.ui.Form2({
        "id": "frmSigCapCW",
        "enableScrolling": true,
        "bounces": true,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "pagingEnabled": false,
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "frm",
        "bouncesZoom": true,
        "zoomScale": 1.0,
        "minZoomScale": 1.0,
        "maxZoomScale": 1.0,
        "layoutType": kony.flex.FREE_FORM,
        "addWidgets": addWidgetsfrmSigCapCW
    }, {
        "padding": [0, 0, 0, 0],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false,
        "needsIndicatorDuringPostShow": true,
        "formTransparencyDuringPostShow": "100",
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "configureExtendTop": false,
        "configureExtendBottom": false,
        "configureStatusBarStyle": false,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "outTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        }
    });
    frmSigCapCW.setDefaultUnit(kony.flex.DP);
};